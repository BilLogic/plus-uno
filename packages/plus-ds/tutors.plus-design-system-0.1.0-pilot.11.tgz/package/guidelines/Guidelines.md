# PLUS Design System

This project uses the PLUS Design System (`@tutors.plus/design-system`).
Files in the `guidelines/` directory explain how to use it.

IMPORTANT: ALWAYS prefer PLUS components over building custom UI elements.

---

## Component Usage Guidelines - READ THIS FIRST

IMPORTANT: Follow these steps **IN ORDER** before writing any code:

### Step 1: Read Overview Files (REQUIRED)
Read ALL files with a name that starts with `overview-` in the guidelines directory:
- `overview-components.md`
- `overview-icons.md`

### Step 2: Read Design Tokens (REQUIRED)
Read ALL files in the `design-tokens/` folder. Do NOT skip this step.
- `design-tokens/colors.md`
- `design-tokens/spacing.md`
- `design-tokens/typography.md`

### Step 3: Plan What Components You Need (REQUIRED)
Before coding, list out which PLUS components you will use.

### Step 4: Read Component Guidelines BEFORE Using Components (REQUIRED)
BEFORE using ANY component, you MUST read its guidelines file first:
- Using Button? → Read `guidelines/components/button.md` FIRST
- Using Badge? → Read `guidelines/components/badge.md` FIRST
- Using ButtonGroup? → Read `guidelines/components/buttongroup.md` FIRST
- Using Alert? → Read `guidelines/components/alert.md` FIRST

### Step 5: Plan What Icons You Need (REQUIRED)
Before using ANY icon, check `overview-icons.md` to verify the icon name exists.

**DO NOT write code using a component until you have read its specific guidelines.**

---

## Setup

### Installation
```bash
npm install @tutors.plus/design-system react-bootstrap bootstrap @fortawesome/fontawesome-free @fontsource/lato @fontsource/merriweather-sans @fontsource/open-sans @fontsource/source-code-pro
```

### Usage (App Entry)
```jsx
// 1. Import Fonts
import '@fontsource/lato/300.css';
import '@fontsource/lato/400.css';
import '@fontsource/lato/700.css';
import '@fontsource/merriweather-sans/300.css';
import '@fontsource/merriweather-sans/400.css';
import '@fontsource/merriweather-sans/700.css';

// 2. Import Base Styles
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.min.css';
import '@tutors.plus/design-system/styles';

// 3. Import Components
import { Button, Alert, Badge } from '@tutors.plus/design-system';
```

---

## Token Usage Rules (CRITICAL)

ALWAYS use design tokens. NEVER hardcode values.

✅ **CORRECT**:
```css
.card {
  background: var(--color-surface-container);
  padding: var(--size-element-pad-x-md);
  border-radius: var(--size-element-radius-md);
}
```

❌ **WRONG**:
```css
.card {
  background: #f5f5f5;
  padding: 10px;
  border-radius: 4px;
}
```

---

## Color Roles

| Role | Token | Use For |
|------|-------|---------|
| Primary | `var(--color-primary)` | Main brand color, primary buttons |
| Secondary | `var(--color-secondary)` | Secondary actions |
| Success | `var(--color-success)` | Success states, confirmations |
| Warning | `var(--color-warning)` | Warnings, caution states |
| Danger | `var(--color-danger)` | Errors, destructive actions |
| Info | `var(--color-info)` | Informational messages |
